Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices


<Assembly: AssemblyTitle("")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("")> 
<Assembly: AssemblyProduct("")> 
<Assembly: AssemblyCopyright("")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: CLSCompliant(True)> 

<Assembly: Guid("3EB9FC30-C1FB-490C-A04A-73F9D71F2085")> 


<Assembly: AssemblyVersion("1.0.*")> 
